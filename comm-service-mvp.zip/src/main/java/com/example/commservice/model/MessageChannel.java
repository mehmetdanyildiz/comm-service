package com.example.commservice.model;

public enum MessageChannel { HTTP, RABBITMQ, WEBSOCKET }
