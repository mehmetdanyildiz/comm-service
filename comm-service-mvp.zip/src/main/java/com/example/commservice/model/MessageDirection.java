package com.example.commservice.model;

public enum MessageDirection { OUTBOUND, INBOUND }
