package com.example.commservice.model;

public enum MessageStatus { SUCCESS, FAILED }
